#pragma once 

#include <gio/gio.h> 

/* Export MediaEndpoint1 objects */ 

int media_endpoint_export(GDBusConnection *conn);