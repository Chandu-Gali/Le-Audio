#pragma once 

#include <gio/gio.h> 

void bluez_register_endpoints(GDBusConnection *conn);