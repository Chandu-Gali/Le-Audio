#include <gio/gio.h>
#include "bluez-media-endpoint.h"
#include "bluez5-dbus.h"
#include <stdio.h>

int main(void)
{
    GMainLoop *loop;
    GDBusConnection *conn;

    conn = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, NULL);
    if (!conn)
        return 1;
    // const char *name = g_dbus_connection_get_unique_name(conn);
    // printf("Owner: %s\n",name);
    media_endpoint_export(conn);
    bluez_register_endpoints(conn);

    g_message("[LEAUDIO] daemon running");

    loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(loop);
    return 0;
}