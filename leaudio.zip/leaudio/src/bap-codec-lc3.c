#include <stdlib.h> 
#include <string.h> 
#include <errno.h> 
#include <stdio.h> 
#include <stdint.h> 

#include <lc3.h> 
#include "bap-codec-lc3.h" 

static int lc3_parse_framelen(const uint8_t *cc, size_t len); 
static int lc3_parse_frame_us(const uint8_t *cc, size_t len); 
struct lc3_codec { 
    lc3_encoder_t enc[LEAUDIO_MAX_CHANNELS]; 
    lc3_decoder_t dec[LEAUDIO_MAX_CHANNELS]; 
   
    void *enc_mem[LEAUDIO_MAX_CHANNELS]; 
    void *dec_mem[LEAUDIO_MAX_CHANNELS]; 
   
    int samplerate; 
    int codec_samplerate; 
    int channels; 
    int frame_us; 
    int framelen; 
    int samples; 
    size_t pcm_bytes; 
};

struct lc3_codec *lc3_codec_create(
        int samplerate,
        int channels,
        int frame_us,
        int framelen)
{
    struct lc3_codec *c;
    int i;

    if (channels <= 0 || channels > LEAUDIO_MAX_CHANNELS)
        return NULL;

    c = calloc(1, sizeof(*c));
    if (!c)
        return NULL;

    c->samplerate = samplerate;
    c->codec_samplerate = (samplerate == 44100) ? 48000 : samplerate;
    c->channels = channels;
    c->frame_us = frame_us;
    c->framelen = framelen;

    c->samples = lc3_frame_samples(frame_us, c->codec_samplerate);
    if (c->samples <= 0)
        goto fail;

    /* S16 PCM */
    c->pcm_bytes = c->samples * channels * sizeof(int16_t);

    for (i = 0; i < channels; i++) {
        c->enc_mem[i] = calloc(1,
            lc3_encoder_size(frame_us, c->codec_samplerate));
        if (!c->enc_mem[i])
            goto fail;

        c->enc[i] = lc3_setup_encoder(frame_us,
                                      c->codec_samplerate,
                                      0,
                                      c->enc_mem[i]);
        if (!c->enc[i])
            goto fail;

        c->dec_mem[i] = calloc(1,
            lc3_decoder_size(frame_us, c->codec_samplerate));
        if (!c->dec_mem[i])
            goto fail;

        c->dec[i] = lc3_setup_decoder(frame_us,
                                      c->codec_samplerate,
                                      0,
                                      c->dec_mem[i]);
        if (!c->dec[i])
            goto fail;
    }

    return c;

fail:
    lc3_codec_destroy(c);
    return NULL;
}

void lc3_codec_destroy(struct lc3_codec *c)
{
    if (!c) return;
    for (int i = 0; i < c->channels; i++) {
        free(c->enc_mem[i]);
        free(c->dec_mem[i]);
    }
    free(c);
}

int lc3_codec_encode(
        struct lc3_codec *c,
        const int16_t *pcm,
        size_t pcm_bytes,
        uint8_t *out,
        size_t out_size,
        size_t *out_bytes)
{
    if (!c || !pcm || !out || !out_bytes)
        return -EINVAL;

    if (pcm_bytes < c->pcm_bytes || out_size < (size_t)(c->framelen * c->channels))
        return -EINVAL;

    size_t written = 0;
    for (int ch = 0; ch < c->channels; ch++) {
        const int16_t *in = pcm + ch;
        uint8_t *dst = out + ch * c->framelen;

        if (lc3_encode(c->enc[ch],
                       LC3_PCM_FORMAT_S16,
                       (const void *)in,
                       c->channels,
                       c->framelen,
                       dst) != 0)
            return -EIO;

        written += c->framelen;
    }
    *out_bytes = written;
    return 0;
}

int lc3_codec_decode(
        struct lc3_codec *c,
        const uint8_t *in,
        size_t in_size,
        int16_t *pcm,
        size_t pcm_size,
        size_t *pcm_bytes)
{
    if (!c || !in || !pcm || !pcm_bytes)
        return -EINVAL;

    if (in_size < (size_t)(c->framelen * c->channels) || pcm_size < c->pcm_bytes)
        return -EINVAL;

    for (int ch = 0; ch < c->channels; ch++) {
        const uint8_t *src = in + ch * c->framelen;
        int16_t *dst = pcm + ch;

        if (lc3_decode(c->dec[ch],
                       src,
                       c->framelen,
                       LC3_PCM_FORMAT_S16,
                       dst,
                       c->channels) < 0)
            return -EIO;
    }

    *pcm_bytes = c->pcm_bytes;
    return 0;
}

int lc3_codec_plc(
        struct lc3_codec *c,
        int16_t *pcm,
        size_t pcm_size)
{
    if (!c || !pcm || pcm_size < c->pcm_bytes)
        return -EINVAL;

    for (int ch = 0; ch < c->channels; ch++) {
        int16_t *dst = pcm + ch;
        if (lc3_decode(c->dec[ch],
                       NULL,
                       0,
                       LC3_PCM_FORMAT_S16,
                       dst,
                       c->channels) < 0)
            return -EIO;
    }

    return 0;
}

/* -------- Accessors -------- */
size_t bap_lc3_get_frame_samples(struct lc3_codec *c) { return c->samples; }
int bap_lc3_get_channels(struct lc3_codec *c) { return c->channels; }
size_t bap_lc3_get_pcm_bytes(struct lc3_codec *c) { return c->pcm_bytes; }
size_t bap_lc3_get_octets_per_frame(struct lc3_codec *c) { return c->framelen; }

/* -------- CodecConfiguration parsing -------- */
static int lc3_parse_framelen(const uint8_t *cc, size_t len)
{
    for (size_t i = 0; i + 3 < len; ) {
        uint8_t l = cc[i];
        uint8_t t = cc[i + 1];
        if (t == 0x04 && l == 2)
            return cc[i + 2] | (cc[i + 3] << 8);
        i += l + 2;
    }
    return -EINVAL;
}

static int lc3_parse_frame_us(const uint8_t *cc, size_t len)
{
    for (size_t i = 0; i + 2 < len; ) {
        uint8_t l = cc[i];
        uint8_t t = cc[i + 1];
        if (t == 0x02 && l == 1)
            return (cc[i + 2] == 0x02) ? 10000 : 7500;
        i += l + 2;
    }
    return -EINVAL;
}

struct lc3_codec *lc3_codec_create_from_cc(
        const uint8_t *cc,
        size_t cc_len,
        int samplerate,
        int channels)
{
    int framelen = lc3_parse_framelen(cc, cc_len);
    int frame_us = lc3_parse_frame_us(cc, cc_len);

    if (framelen <= 0 || frame_us <= 0)
        return NULL;

    return lc3_codec_create(samplerate, channels, frame_us, framelen);
}



