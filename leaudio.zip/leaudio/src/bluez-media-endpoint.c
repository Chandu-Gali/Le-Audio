#include <gio/gio.h>
#include <gio/gunixfdlist.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#include "bap-codec-lc3.h"

#define EP_PATH_SOURCE "/local/endpoint/ep0"
#define EP_PATH_SINK   "/local/endpoint/ep1"

static GDBusConnection *g_conn;

/* ================= ENDPOINT CONTEXT ================= */

struct endpoint_ctx {
    const char *path;
    char *transport;
    char *state;

    int iso_fd;
    guint16 mtu;
    guint16 interval;

    gboolean configured;
    gboolean acquired;
    gboolean streaming;
    gboolean playing;

    GThread *thread;

    int lc3_frame_bytes;

    FILE *wav;

    struct lc3_codec *lc3;   /* LC3 handle */
    size_t pcm_bytes;        /* bytes per frame */
    int16_t pcm_buf[480];    /* enough for 10 ms mono */
};


static struct endpoint_ctx ep_source = { .path = EP_PATH_SOURCE, .iso_fd = -1, .state = NULL };
static struct endpoint_ctx ep_sink   = { .path = EP_PATH_SINK,   .iso_fd = -1, .state = NULL  };

/* ================= UTIL ================= */

static gboolean is_source_endpoint(struct endpoint_ctx *ctx)
{
    return g_strcmp0(ctx->path, EP_PATH_SOURCE) == 0;
}

/* ================= ISO TX THREAD ================= */
static gpointer iso_tx_thread(gpointer data)
{
    struct endpoint_ctx *ctx = data;

    uint8_t frame[512];

    g_message("ISO TX thread running frame=%u pcm=%zu",
              ctx->lc3_frame_bytes,
              ctx->pcm_bytes);

/* ===== PREFILL 3 SDUs to avoid NRF underrun ===== */
for (int i = 0; i < 3; i++) {

    size_t n = fread(ctx->pcm_buf, 1, ctx->pcm_bytes, ctx->wav);
    if (n < ctx->pcm_bytes)
        fseek(ctx->wav, 44, SEEK_SET);

    size_t out_bytes = 0;

    int ret = lc3_codec_encode(
        ctx->lc3,
        (int16_t *)ctx->pcm_buf,
        ctx->pcm_bytes,
        frame,
        sizeof(frame),
        &out_bytes
    );

    if (ret == 0 && out_bytes == (size_t)ctx->lc3_frame_bytes) {
        write(ctx->iso_fd, frame, out_bytes);
    }
}

    
    while (ctx->streaming) {

        /* Read PCM frame */
        size_t n = fread(ctx->pcm_buf, 1, ctx->pcm_bytes, ctx->wav);

        if (n < ctx->pcm_bytes) {
            fseek(ctx->wav, 44, SEEK_SET);
            continue;
        }

        size_t out_bytes = 0;

        int ret = lc3_codec_encode(
            ctx->lc3,
            (int16_t *)ctx->pcm_buf,
            ctx->pcm_bytes,
            frame,
            sizeof(frame),
            &out_bytes
        );

        if (ret < 0 || out_bytes != (size_t)ctx->lc3_frame_bytes) {
            g_warning("LC3 encode failed ret=%d out=%zu", ret, out_bytes);
            continue;
        }

        /* BLOCKING write — kernel handles ISO pacing */
        ssize_t w = write(ctx->iso_fd, frame, out_bytes);

        if (w < 0) {
            perror("ISO write failed");
            break;
        }
    }

    g_message("ISO TX thread exit");
    return NULL;
}


static void start_iso(struct endpoint_ctx *ctx)
{
    if (!ctx->acquired || ctx->streaming || ctx->iso_fd < 0)
        return;

    g_message("ISO start: fd=%d acquired=%d playing=%d frame=%u interval=%u",
              ctx->iso_fd, ctx->acquired, ctx->playing,
              ctx->lc3_frame_bytes, ctx->interval);

    /* ================= Open WAV ================= */
    ctx->wav = fopen("audio/test_hindi.wav1", "rb");
    if (!ctx->wav) {
        perror("wav open");
        return;
    }

    /* Skip WAV header (44 bytes for PCM) */
    fseek(ctx->wav, 44, SEEK_SET);

    /* ================= Create LC3 encoder ================= */
    ctx->lc3 = lc3_codec_create(
        48000,                 /* sample rate */
        1,                     /* mono */
        10000,                 /* 10 ms frame */
        ctx->lc3_frame_bytes   /* SDU size from QoS */
    );

    if (!ctx->lc3) {
        g_warning("LC3 create failed");
        fclose(ctx->wav);
        ctx->wav = NULL;
        return;
    }

    /* ================= Get PCM frame size ================= */
    ctx->pcm_bytes = bap_lc3_get_pcm_bytes(ctx->lc3);

    if (ctx->pcm_bytes == 0 || ctx->pcm_bytes > sizeof(ctx->pcm_buf)) {
        g_warning("Invalid pcm_bytes=%zu", ctx->pcm_bytes);
        lc3_codec_destroy(ctx->lc3);
        ctx->lc3 = NULL;
        fclose(ctx->wav);
        ctx->wav = NULL;
        return;
    }

    g_message("LC3 ready pcm_bytes=%zu frame_bytes=%u",
              ctx->pcm_bytes,
              ctx->lc3_frame_bytes);

    /* ================= Start TX thread ================= */
    ctx->streaming = TRUE;

    g_message("Starting ISO TX thread");
    ctx->thread = g_thread_new("iso-tx", iso_tx_thread, ctx);

    // if (is_source_endpoint(ctx))
    // ctx->thread = g_thread_new("iso-tx", iso_tx_thread, ctx);


//     ctx->streaming = TRUE;

// if (is_source_endpoint(ctx)) {
//     g_message("Starting ISO TX thread");
//     ctx->thread = g_thread_new("iso-tx", iso_tx_thread, ctx);
// }

}



static void stop_iso(struct endpoint_ctx *ctx)
{
    if (!ctx->streaming)
        return;

    g_message("ISO stop (%s)", is_source_endpoint(ctx) ? "TX" : "RX");

    ctx->streaming = FALSE;

    if (ctx->thread) {
        g_thread_join(ctx->thread);
        ctx->thread = NULL;
    }

    if (ctx->lc3) {
        lc3_codec_destroy(ctx->lc3);
        ctx->lc3 = NULL;
    }

    if (ctx->wav) {
        fclose(ctx->wav);
        ctx->wav = NULL;
    }
}


// /* ================= RELEASE ================= */

// static void handle_release(struct endpoint_ctx *ctx)
// {
//     g_message("Transport Release %s", ctx->transport);

//     stop_iso(ctx);

//     if (ctx->iso_fd >= 0) {
//         close(ctx->iso_fd);
//         ctx->iso_fd = -1;
//     }

//     ctx->acquired = FALSE;
//     ctx->playing = FALSE;
// }

/* ================= ACQUIRE ================= */


static void acquire_cb(GObject *source, GAsyncResult *res, gpointer user_data)
{
    struct endpoint_ctx *ctx = user_data;
    GError *err = NULL;
    GUnixFDList *fd_list = NULL;

    GVariant *ret =
        g_dbus_connection_call_with_unix_fd_list_finish(
            G_DBUS_CONNECTION(source),
            &fd_list,
            res,
            &err);

    /* Ignore failed Acquire (expected for SOURCE) */
    if (!ret) {
        if (err)
            g_clear_error(&err);
        return;
    }

    gint fd_index;
    g_variant_get(ret, "(hqq)", &fd_index, &ctx->mtu, &ctx->interval);

    ctx->iso_fd = g_unix_fd_list_get(fd_list, fd_index, &err);

    if (ctx->iso_fd < 0) {
        g_warning("Failed to get ISO fd: %s", err->message);
        g_clear_error(&err);
        g_variant_unref(ret);
        return;
    }

    ctx->acquired = TRUE;

    /* ISO must be blocking */
    int flags = fcntl(ctx->iso_fd, F_GETFL, 0);
    fcntl(ctx->iso_fd, F_SETFL, flags & ~O_NONBLOCK);

    g_message("ISO FD %d set to BLOCKING mode", ctx->iso_fd);

    ctx->lc3_frame_bytes = ctx->mtu;

    g_message("Acquire OK fd=%d mtu=%u", ctx->iso_fd, ctx->mtu);

    /* Start ISO when SOURCE becomes active */
    if (is_source_endpoint(ctx) && !ctx->streaming)
        start_iso(ctx);

    /* RX path (not used now, but safe) */
    if (!is_source_endpoint(ctx) && !ctx->streaming)
        start_iso(ctx);

    g_variant_unref(ret);
}


static void acquire_transport_async(struct endpoint_ctx *ctx)
{
    if (!ctx->transport || ctx->acquired)
        return;

    g_message("Calling Acquire on %s", ctx->transport);

    g_dbus_connection_call_with_unix_fd_list(
        g_conn,
        "org.bluez",
        ctx->transport,
        "org.bluez.MediaTransport1",
        "Acquire",
        NULL,
        G_VARIANT_TYPE("(hqq)"),
        G_DBUS_CALL_FLAGS_NONE,
        -1,
        NULL,
        NULL,
        acquire_cb,
        ctx);
}


/* ================= TRANSPORT STATE MACHINE ================= */

static void transport_props_changed(GDBusConnection *conn,
                                    const char *sender,
                                    const char *path,
                                    const char *iface,
                                    const char *signal,
                                    GVariant *params,
                                    gpointer user_data)
{
    (void)conn; (void)sender; (void)path; (void)iface; (void)signal;

    struct endpoint_ctx *ctx = user_data;

    const char *interface;
    GVariant *changed;
    GVariantIter *iter;
    const char *key;
    GVariant *value;

    const char *state = NULL;
    gboolean playing = FALSE;

    g_variant_get(params, "(&s@a{sv}@as)", &interface, &changed, NULL);

    if (g_strcmp0(interface, "org.bluez.MediaTransport1") != 0) {
        g_variant_unref(changed);
        return;
    }

    iter = g_variant_iter_new(changed);

    while (g_variant_iter_next(iter, "{&sv}", &key, &value)) {

        if (g_strcmp0(key, "State") == 0)
            state = g_variant_get_string(value, NULL);
        else if (g_strcmp0(key, "Playing") == 0)
            playing = g_variant_get_boolean(value);

        g_variant_unref(value);
    }

    g_variant_iter_free(iter);
    g_variant_unref(changed);

    ctx->playing = playing;

    g_message("Transport %s state=%s playing=%d",
              ctx->transport,
              state ? state : "NULL",
              playing);

    /* Save state */
if (state) {
    g_free(ctx->state);
    ctx->state = g_strdup(state);
}
if (ctx->state &&
    g_strcmp0(ctx->state, "active") == 0 &&
    !ctx->acquired)
{
    g_message("Transport ACTIVE : calling Acquire");
    acquire_transport_async(ctx);
}


if (ctx->state && g_strcmp0(ctx->state, "pending") == 0) {
    if (!ctx->acquired) {
        g_message("Transport pending calling Acquire");
        acquire_transport_async(ctx);
    }
}


if (ctx->state && g_strcmp0(ctx->state, "active") == 0) {
    if (ctx->acquired && !ctx->streaming && is_source_endpoint(ctx)) {
        g_message("SOURCE active → start ISO TX");
        start_iso(ctx);
    }
}


/* Stop ISO when transport goes idle */
if (ctx->state && g_strcmp0(ctx->state, "idle") == 0) {
    if (ctx->streaming)
        stop_iso(ctx);
}

}

static void subscribe_transport_signals(struct endpoint_ctx *ctx)
{
    if (!ctx->transport || !g_conn)
        return;

    g_dbus_connection_signal_subscribe(
        g_conn,
        "org.bluez",
        "org.freedesktop.DBus.Properties",
        "PropertiesChanged",
        ctx->transport,
        NULL,
        G_DBUS_SIGNAL_FLAGS_NONE,
        transport_props_changed,
        ctx,
        NULL);

    g_message("Subscribed to transport signals: %s", ctx->transport);
}

/* ================= MEDIA ENDPOINT METHODS ================= */

static void handle_select_properties(GDBusMethodInvocation *inv)
{
    GVariantBuilder reply;
    GVariantBuilder qos;

    static const uint8_t lc3_cfg[] = {
        0x02, 0x01, 0x08,
        0x02, 0x02, 0x01,
        0x05, 0x03, 0x01, 0x00, 0x00, 0x00,
        0x03, 0x04, 0x9B, 0x00,
        0x02, 0x05, 0x01
    };

    g_variant_builder_init(&reply, G_VARIANT_TYPE("a{sv}"));
    g_variant_builder_init(&qos,   G_VARIANT_TYPE("a{sv}"));

    g_variant_builder_add(&qos, "{sv}", "CIG", g_variant_new_byte(0));
    g_variant_builder_add(&qos, "{sv}", "CIS", g_variant_new_byte(0));
    g_variant_builder_add(&qos, "{sv}", "Interval", g_variant_new_uint32(10000));
    g_variant_builder_add(&qos, "{sv}", "Framing", g_variant_new_byte(0));
    g_variant_builder_add(&qos, "{sv}", "PHY", g_variant_new_byte(2));
    g_variant_builder_add(&qos, "{sv}", "SDU", g_variant_new_uint16(155));
    g_variant_builder_add(&qos, "{sv}", "Retransmissions", g_variant_new_byte(2));
    g_variant_builder_add(&qos, "{sv}", "Latency", g_variant_new_uint16(10));
    g_variant_builder_add(&qos, "{sv}", "PresentationDelay", g_variant_new_uint32(40000));
    g_variant_builder_add(&qos, "{sv}", "TargetLatency", g_variant_new_byte(2));

    g_variant_builder_add(&reply, "{sv}", "Capabilities",
        g_variant_new_fixed_array(G_VARIANT_TYPE_BYTE,
                                  lc3_cfg,
                                  sizeof(lc3_cfg),
                                  sizeof(uint8_t)));

    g_variant_builder_add(&reply, "{sv}", "QoS",
        g_variant_builder_end(&qos));

    g_dbus_method_invocation_return_value(
        inv,
        g_variant_new("(@a{sv})",
            g_variant_builder_end(&reply)));
}

static void handle_set_configuration(
        GDBusMethodInvocation *inv,
        GVariant *params,
        struct endpoint_ctx *ctx)
{
    const char *transport;
    GVariant *properties = NULL;

    g_variant_get(params, "(&o@a{sv})", &transport, &properties);

g_clear_pointer(&properties, g_variant_unref);
    g_clear_pointer(&ctx->transport, g_free);
    ctx->transport = g_strdup(transport);

    ctx->configured = TRUE;
    ctx->acquired = FALSE;
    ctx->streaming = FALSE;
    ctx->playing = FALSE;
    ctx->iso_fd = -1;
g_clear_pointer(&ctx->state, g_free);
ctx->state = NULL;


    ctx->lc3_frame_bytes = 155; /* SDU */

    g_message("SetConfiguration OK for %s transport %s",
              ctx->path, ctx->transport);

    subscribe_transport_signals(ctx);
    
    // if (is_source_endpoint(ctx))
        // acquire_transport_async(ctx);

    /* Only auto-acquire SINK transport (uplink / mic path) */
if (!is_source_endpoint(ctx)){
    acquire_transport_async(ctx);
}

    g_dbus_method_invocation_return_value(inv, NULL);
}

/* ================= DBUS EXPORT ================= */

static void method_call_cb(GDBusConnection *c,
                           const char *s,
                           const char *path,
                           const char *i,
                           const char *m,
                           GVariant *p,
                           GDBusMethodInvocation *inv,
                           void *u)
{
    (void)c; (void)s; (void)i; (void)u;

    struct endpoint_ctx *ctx =
        strcmp(path, EP_PATH_SOURCE) == 0 ? &ep_source : &ep_sink;

    if (!strcmp(m, "SelectProperties"))
        handle_select_properties(inv);
    else if (!strcmp(m, "SetConfiguration"))
        handle_set_configuration(inv, p, ctx);
//     else if (!strcmp(m, "Release"))
//         handle_release(ctx);
}

int media_endpoint_export(GDBusConnection *conn)
{
    GDBusNodeInfo *node;
    GError *err = NULL;

    g_conn = conn;

    static const char xml[] =
    "<node>"
    " <interface name='org.bluez.MediaEndpoint1'>"
    "  <method name='SelectProperties'>"
    "   <arg type='a{sv}' direction='in'/>"
    "   <arg type='a{sv}' direction='out'/>"
    "  </method>"
    "  <method name='SetConfiguration'>"
    "   <arg type='o' direction='in'/>"
    "   <arg type='a{sv}' direction='in'/>"
    "  </method>"
    " </interface>"
    "</node>";

    node = g_dbus_node_info_new_for_xml(xml, &err);

    static const GDBusInterfaceVTable vt = {
        .method_call = method_call_cb
    };

    g_dbus_connection_register_object(conn, EP_PATH_SOURCE,
        node->interfaces[0], &vt, NULL, NULL, NULL);

    g_dbus_connection_register_object(conn, EP_PATH_SINK,
        node->interfaces[0], &vt, NULL, NULL, NULL);

    g_dbus_node_info_unref(node);
    return 0;
}
