==> rm leaudiod 

==> gcc -std=gnu99 -Wall -Wextra -O0 -g     -Iinclude     src/main.c \       
    src/bluez-media-endpoint.c     src/bluez5-dbus.c     src/bap-codec-lc3.c  \  
    -llc3     $(pkg-config --cflags --libs gio-2.0 gio-unix-2.0 glib-2.0)
    -o leaudiod

==> sudo ./leaudiod 


Output: the audio will play in loop. Daemon sending the audio using fd.

these are the logs:

sachin@sachin-9-Notebook-PC:~/le_audi_bakup/leaudio$ sudo ./leaudiod 
[BlueZ] Registered /local/endpoint/ep0 (00002bc9-0000-1000-8000-00805f9b34fb)
[BlueZ] Registered /local/endpoint/ep1 (00002bcb-0000-1000-8000-00805f9b34fb)
** Message: 15:33:25.504: [LEAUDIO] daemon running
** Message: 15:33:25.692: SetConfiguration OK for /local/endpoint/ep0 transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd18
** Message: 15:33:25.693: Subscribed to transport signals: /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd18
** Message: 15:33:42.748: SetConfiguration OK for /local/endpoint/ep0 transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd19
** Message: 15:33:42.748: Subscribed to transport signals: /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd19
** Message: 15:33:42.837: SetConfiguration OK for /local/endpoint/ep1 transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_sink0/fd20
** Message: 15:33:42.838: Subscribed to transport signals: /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_sink0/fd20
** Message: 15:33:42.838: Calling Acquire on /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_sink0/fd20
** Message: 15:33:42.838: Transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd19 state=NULL playing=0
** Message: 15:33:43.377: ISO FD 8 set to BLOCKING mode
** Message: 15:33:43.377: Acquire OK fd=8 mtu=155
** Message: 15:33:43.377: ISO start: fd=8 acquired=1 playing=0 frame=155 interval=155
** Message: 15:33:43.377: LC3 ready pcm_bytes=960 frame_bytes=155
** Message: 15:33:43.377: Starting ISO TX thread
** Message: 15:33:43.378: ISO TX thread running frame=155 pcm=960
** Message: 15:33:43.378: Transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_sink0/fd20 state=active playing=0
** Message: 15:33:43.379: Transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd19 state=active playing=0
** Message: 15:33:43.379: Transport ACTIVE : calling Acquire
** Message: 15:33:43.379: Calling Acquire on /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd19

** Message: 15:20:56.075: Transport /org/bluez/hci0/dev_48_49_71_9B_D6_74/pac_source0/fd16 state=NULL playing=0
