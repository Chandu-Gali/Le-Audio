/*
 * gtbs_server.c — Generic Telephony Bearer Service (GTBS) GATT Server
 *
 * Registers with BlueZ via D-Bus GattManager1.RegisterApplication so that
 * an nRF peripheral's ccp_call_ctrl_init() can discover GTBS (UUID 0x184C).
 *
 * Build:
 *   gcc $(pkg-config --cflags --libs gio-2.0 glib-2.0) -o gtbs_server gtbs_server.c
 *
 * Run (as root or with CAP_NET_ADMIN):
 *   ./gtbs_server
 */

#include <gio/gio.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

/* ── UUIDs ──────────────────────────────────────────────────────────────── */
#define GTBS_UUID                      "0000184c-0000-1000-8000-00805f9b34fb"
#define BEARER_PROVIDER_NAME_UUID      "00002bb3-0000-1000-8000-00805f9b34fb"
#define BEARER_UCI_UUID                "00002bb4-0000-1000-8000-00805f9b34fb"
#define BEARER_TECHNOLOGY_UUID         "00002bb5-0000-1000-8000-00805f9b34fb"
#define BEARER_URI_SCHEMES_UUID        "00002bb6-0000-1000-8000-00805f9b34fb"
#define BEARER_SIGNAL_STRENGTH_UUID    "00002bb7-0000-1000-8000-00805f9b34fb"
#define BEARER_LIST_CURRENT_CALLS_UUID "00002bb9-0000-1000-8000-00805f9b34fb"
#define CONTENT_CONTROL_ID_UUID        "00002bba-0000-1000-8000-00805f9b34fb"
#define STATUS_FLAGS_UUID              "00002bbb-0000-1000-8000-00805f9b34fb"
#define INCOMING_CALL_TARGET_URI_UUID  "00002bbc-0000-1000-8000-00805f9b34fb"
#define CALL_STATE_UUID                "00002bbd-0000-1000-8000-00805f9b34fb"
#define CALL_CONTROL_POINT_UUID        "00002bbe-0000-1000-8000-00805f9b34fb"
#define CALL_CONTROL_POINT_OPC_UUID    "00002bbf-0000-1000-8000-00805f9b34fb"
#define TERMINATION_REASON_UUID        "00002bc0-0000-1000-8000-00805f9b34fb"
#define INCOMING_CALL_UUID             "00002bc1-0000-1000-8000-00805f9b34fb"
#define CALL_FRIENDLY_NAME_UUID        "00002bc2-0000-1000-8000-00805f9b34fb"
#define CCCD_UUID                      "00002902-0000-1000-8000-00805f9b34fb"

/* ── D-Bus interfaces ───────────────────────────────────────────────────── */
#define BLUEZ_SERVICE       "org.bluez"
#define DBUS_OM_IFACE       "org.freedesktop.DBus.ObjectManager"
#define DBUS_PROP_IFACE     "org.freedesktop.DBus.Properties"
#define GATT_MANAGER_IFACE  "org.bluez.GattManager1"
#define GATT_SERVICE_IFACE  "org.bluez.GattService1"
#define GATT_CHRC_IFACE     "org.bluez.GattCharacteristic1"
#define GATT_DESC_IFACE     "org.bluez.GattDescriptor1"

#define APP_PATH            "/gtbs/app"
#define SVC_PATH            APP_PATH "/service0"

/* ── Bearer technology ──────────────────────────────────────────────────── */
#define BEARER_TECHNOLOGY_LTE  0x04

/* ── CCP opcodes ────────────────────────────────────────────────────────── */
#define CCP_OPC_ACCEPT          0x00
#define CCP_OPC_TERMINATE       0x01
#define CCP_OPC_LOCAL_HOLD      0x02
#define CCP_OPC_LOCAL_RETRIEVE  0x03
#define CCP_OPC_ORIGINATE       0x04
#define CCP_OPC_JOIN            0x05

/* ── CCP result codes ───────────────────────────────────────────────────── */
#define CCP_RESULT_SUCCESS              0x00
#define CCP_RESULT_OPCODE_NOT_SUPPORTED 0x01
#define CCP_RESULT_INVALID_CALL_INDEX   0x03

/* ── Call states ────────────────────────────────────────────────────────── */
#define CALL_STATE_INCOMING    0x00
#define CALL_STATE_DIALING     0x01
#define CALL_STATE_ALERTING    0x02
#define CALL_STATE_ACTIVE      0x03
#define CALL_STATE_LOCAL_HOLD  0x04

/* ── Max calls tracked ──────────────────────────────────────────────────── */
#define MAX_CALLS 8

/* ── Characteristic IDs (array indices) ────────────────────────────────── */
enum {
    CHRC_PROVIDER_NAME = 0,
    CHRC_UCI,
    CHRC_TECHNOLOGY,
    CHRC_URI_SCHEMES,
    CHRC_SIGNAL_STRENGTH,
    CHRC_CURRENT_CALLS,
    CHRC_CCID,
    CHRC_STATUS_FLAGS,
    CHRC_CALL_STATE,
    CHRC_CCP,
    CHRC_CCP_OPC,
    CHRC_TERM_REASON,
    CHRC_INCOMING_CALL,
    CHRC_FRIENDLY_NAME,
    CHRC_COUNT
};

/* ── Call record ────────────────────────────────────────────────────────── */
typedef struct {
    gboolean active;
    guint8   state;
    char     uri[256];
} Call;

/* ── Global state ───────────────────────────────────────────────────────── */
static GDBusConnection *g_bus        = NULL;
static GMainLoop       *g_loop       = NULL;
static guint            g_reg_ids[64]; /* node registration IDs */
static guint            g_reg_count  = 0;

/* Characteristic paths */
static char g_chrc_paths[CHRC_COUNT][128];
/* Characteristic values */
static GByteArray *g_chrc_values[CHRC_COUNT];
/* Notify state */
static gboolean    g_notifying[CHRC_COUNT];

/* CCCD paths and values */
static char        g_cccd_paths[CHRC_COUNT][160];
static guint8      g_cccd_values[CHRC_COUNT][2];

/* Call table */
static Call  g_calls[MAX_CALLS];
static guint g_next_call_index = 1;

/* ── Helpers ────────────────────────────────────────────────────────────── */

static GByteArray *bytes_from_utf8(const char *s)
{
    GByteArray *a = g_byte_array_new();
    g_byte_array_append(a, (const guint8 *)s, strlen(s));
    return a;
}

static GByteArray *bytes_from_u8(guint8 v)
{
    GByteArray *a = g_byte_array_new();
    g_byte_array_append(a, &v, 1);
    return a;
}

static GByteArray *bytes_from_u16le(guint16 v)
{
    guint8 buf[2] = { (guint8)(v & 0xFF), (guint8)(v >> 8) };
    GByteArray *a = g_byte_array_new();
    g_byte_array_append(a, buf, 2);
    return a;
}

static GVariant *bytearray_to_variant(GByteArray *arr)
{
    GVariantBuilder b;
    g_variant_builder_init(&b, G_VARIANT_TYPE("ay"));
    for (guint i = 0; i < arr->len; i++)
        g_variant_builder_add(&b, "y", arr->data[i]);
    return g_variant_builder_end(&b);
}

static void send_notify(int chrc_id)
{
    if (!g_notifying[chrc_id])
        return;

    GVariant *val = bytearray_to_variant(g_chrc_values[chrc_id]);
    GVariantBuilder changed;
    g_variant_builder_init(&changed, G_VARIANT_TYPE("a{sv}"));
    g_variant_builder_add(&changed, "{sv}", "Value", val);

    GError *err = NULL;
    g_dbus_connection_emit_signal(
        g_bus,
        NULL,
        g_chrc_paths[chrc_id],
        DBUS_PROP_IFACE,
        "PropertiesChanged",
        g_variant_new("(sa{sv}as)", GATT_CHRC_IFACE,
                      &changed,
                      NULL),
        &err);
    if (err) {
        g_printerr("[GTBS] notify error on chrc %d: %s\n", chrc_id, err->message);
        g_error_free(err);
    }
}

/* ── Call state encoding ────────────────────────────────────────────────── */

static void rebuild_call_state(void)
{
    GByteArray *cs = g_byte_array_new();
    GByteArray *cc = g_byte_array_new();

    for (int i = 0; i < MAX_CALLS; i++) {
        if (!g_calls[i].active) continue;
        guint8 idx = (guint8)(i + 1);

        /* CallState: [index, state, flags] */
        guint8 cs_entry[3] = { idx, g_calls[i].state, 0x00 };
        g_byte_array_append(cs, cs_entry, 3);

        /* CurrentCalls: [len, index, state, flags, ...uri] */
        gsize uri_len = strlen(g_calls[i].uri);
        guint8 entry_len = (guint8)(3 + uri_len);
        guint8 cc_hdr[4] = { entry_len, idx, g_calls[i].state, 0x00 };
        g_byte_array_append(cc, cc_hdr, 4);
        g_byte_array_append(cc, (const guint8 *)g_calls[i].uri, uri_len);
    }

    g_byte_array_free(g_chrc_values[CHRC_CALL_STATE], TRUE);
    g_chrc_values[CHRC_CALL_STATE] = cs;
    send_notify(CHRC_CALL_STATE);

    g_byte_array_free(g_chrc_values[CHRC_CURRENT_CALLS], TRUE);
    g_chrc_values[CHRC_CURRENT_CALLS] = cc;
    send_notify(CHRC_CURRENT_CALLS);
}

/* ── GTBS call API ──────────────────────────────────────────────────────── */

static guint8 gtbs_originate(const char *uri)
{
    /* find a free slot */
    for (int i = 0; i < MAX_CALLS; i++) {
        if (!g_calls[i].active) {
            g_calls[i].active = TRUE;
            g_calls[i].state  = CALL_STATE_DIALING;
            g_strlcpy(g_calls[i].uri, uri, sizeof(g_calls[i].uri));
            guint8 idx = (guint8)(i + 1);
            g_print("[GTBS] Originating call index=%u uri=%s\n", idx, uri);
            rebuild_call_state();
            return idx;
        }
    }
    g_printerr("[GTBS] No free call slots\n");
    return 0;
}

static void gtbs_answer(guint8 call_index)
{
    int slot = call_index - 1;
    if (slot < 0 || slot >= MAX_CALLS || !g_calls[slot].active) {
        g_printerr("[GTBS] answer: unknown call %u\n", call_index);
        return;
    }
    g_calls[slot].state = CALL_STATE_ACTIVE;
    g_print("[GTBS] Call %u answered → ACTIVE\n", call_index);
    rebuild_call_state();
}

static void gtbs_terminate(guint8 call_index, guint8 reason)
{
    int slot = call_index - 1;
    if (slot < 0 || slot >= MAX_CALLS || !g_calls[slot].active) {
        g_printerr("[GTBS] terminate: unknown call %u\n", call_index);
        return;
    }
    g_calls[slot].active = FALSE;

    /* Notify TerminationReason */
    guint8 tr[2] = { call_index, reason };
    g_byte_array_set_size(g_chrc_values[CHRC_TERM_REASON], 0);
    g_byte_array_append(g_chrc_values[CHRC_TERM_REASON], tr, 2);
    send_notify(CHRC_TERM_REASON);

    g_print("[GTBS] Call %u terminated reason=0x%02x\n", call_index, reason);
    rebuild_call_state();
}

static void gtbs_handle_ccp(const guint8 *data, gsize len)
{
    if (len == 0) return;
    guint8 opcode = data[0];
    guint8 call_index = (len > 1) ? data[1] : 0;
    int    slot = call_index - 1;

    g_print("[GTBS] CCP write opcode=0x%02x call_index=%u\n", opcode, call_index);

    guint8 resp[3];
    resp[0] = opcode;

    switch (opcode) {
    case CCP_OPC_ORIGINATE: {
        char uri[256] = {0};
        if (len > 1)
            g_strlcpy(uri, (const char *)(data + 1), MIN(len, sizeof(uri)));
        guint8 idx = gtbs_originate(uri);
        resp[1] = idx;
        resp[2] = CCP_RESULT_SUCCESS;
        break;
    }
    case CCP_OPC_ACCEPT:
        gtbs_answer(call_index);
        resp[1] = call_index;
        resp[2] = CCP_RESULT_SUCCESS;
        break;

    case CCP_OPC_TERMINATE:
        gtbs_terminate(call_index, 0x00);
        resp[1] = call_index;
        resp[2] = CCP_RESULT_SUCCESS;
        break;

    case CCP_OPC_LOCAL_HOLD:
        if (slot >= 0 && slot < MAX_CALLS && g_calls[slot].active)
            g_calls[slot].state = CALL_STATE_LOCAL_HOLD;
        rebuild_call_state();
        resp[1] = call_index;
        resp[2] = CCP_RESULT_SUCCESS;
        break;

    case CCP_OPC_LOCAL_RETRIEVE:
        if (slot >= 0 && slot < MAX_CALLS && g_calls[slot].active)
            g_calls[slot].state = CALL_STATE_ACTIVE;
        rebuild_call_state();
        resp[1] = call_index;
        resp[2] = CCP_RESULT_SUCCESS;
        break;

    default:
        g_printerr("[GTBS] Unhandled CCP opcode 0x%02x\n", opcode);
        resp[1] = 0x00;
        resp[2] = CCP_RESULT_OPCODE_NOT_SUPPORTED;
        break;
    }

    /* Notify CCP result */
    g_byte_array_set_size(g_chrc_values[CHRC_CCP], 0);
    g_byte_array_append(g_chrc_values[CHRC_CCP], resp, 3);
    send_notify(CHRC_CCP);
}

/* ── GDBus method/property handlers ────────────────────────────────────── */

/*
 * Determine which chrc index corresponds to an object path.
 */
static int path_to_chrc(const char *path)
{
    for (int i = 0; i < CHRC_COUNT; i++)
        if (strcmp(g_chrc_paths[i], path) == 0)
            return i;
    return -1;
}

static int path_to_cccd(const char *path)
{
    for (int i = 0; i < CHRC_COUNT; i++)
        if (g_cccd_paths[i][0] && strcmp(g_cccd_paths[i], path) == 0)
            return i;
    return -1;
}

/* GattCharacteristic1 method handler */
static void chrc_method_call(GDBusConnection *conn,
                              const gchar *sender,
                              const gchar *obj_path,
                              const gchar *iface,
                              const gchar *method,
                              GVariant *params,
                              GDBusMethodInvocation *inv,
                              gpointer user_data)
{
    (void)conn; (void)sender; (void)iface; (void)user_data;

    int id = path_to_chrc(obj_path);
    if (id < 0) {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_OBJECT, "Unknown path");
        return;
    }

    if (strcmp(method, "ReadValue") == 0) {
        g_print("[GTBS] ReadValue chrc %d\n", id);
        GVariant *ret = bytearray_to_variant(g_chrc_values[id]);
        g_dbus_method_invocation_return_value(inv, g_variant_new_tuple(&ret, 1));

    } else if (strcmp(method, "WriteValue") == 0) {
        GVariant *varray = NULL;
        g_variant_get(params, "(@aya{sv})", &varray, NULL);
        gsize n = 0;
        const guint8 *data = g_variant_get_fixed_array(varray, &n, 1);
        if (id == CHRC_CCP) {
            gtbs_handle_ccp(data, n);
        } else {
            g_byte_array_set_size(g_chrc_values[id], 0);
            g_byte_array_append(g_chrc_values[id], data, n);
        }
        g_variant_unref(varray);
        g_dbus_method_invocation_return_value(inv, NULL);

    } else if (strcmp(method, "StartNotify") == 0) {
        g_notifying[id] = TRUE;
        g_print("[GTBS] StartNotify chrc %d\n", id);
        g_dbus_method_invocation_return_value(inv, NULL);

    } else if (strcmp(method, "StopNotify") == 0) {
        g_notifying[id] = FALSE;
        g_print("[GTBS] StopNotify chrc %d\n", id);
        g_dbus_method_invocation_return_value(inv, NULL);

    } else {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method %s", method);
    }
}

/* GattDescriptor1 (CCCD) method handler */
static void desc_method_call(GDBusConnection *conn,
                              const gchar *sender,
                              const gchar *obj_path,
                              const gchar *iface,
                              const gchar *method,
                              GVariant *params,
                              GDBusMethodInvocation *inv,
                              gpointer user_data)
{
    (void)conn; (void)sender; (void)iface; (void)user_data;

    int id = path_to_cccd(obj_path);
    if (id < 0) {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_OBJECT, "Unknown CCCD path");
        return;
    }

    if (strcmp(method, "ReadValue") == 0) {
        GVariantBuilder b;
        g_variant_builder_init(&b, G_VARIANT_TYPE("ay"));
        g_variant_builder_add(&b, "y", g_cccd_values[id][0]);
        g_variant_builder_add(&b, "y", g_cccd_values[id][1]);
        GVariant *ret = g_variant_builder_end(&b);
        g_dbus_method_invocation_return_value(inv, g_variant_new_tuple(&ret, 1));

    } else if (strcmp(method, "WriteValue") == 0) {
        GVariant *varray = NULL;
        g_variant_get(params, "(@aya{sv})", &varray, NULL);
        gsize n = 0;
        const guint8 *data = g_variant_get_fixed_array(varray, &n, 1);
        if (n >= 1) g_cccd_values[id][0] = data[0];
        if (n >= 2) g_cccd_values[id][1] = data[1];
        g_variant_unref(varray);
        g_dbus_method_invocation_return_value(inv, NULL);
    } else {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method %s", method);
    }
}

/* ObjectManager.GetManagedObjects */
static void app_method_call(GDBusConnection *conn,
                             const gchar *sender,
                             const gchar *obj_path,
                             const gchar *iface,
                             const gchar *method,
                             GVariant *params,
                             GDBusMethodInvocation *inv,
                             gpointer user_data)
{
    (void)conn; (void)sender; (void)obj_path; (void)iface;
    (void)params; (void)user_data;

    if (strcmp(method, "GetManagedObjects") != 0) {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
        return;
    }

    /* Static characteristic metadata */
    static const struct {
        const char *uuid;
        const char *flags[6]; /* NULL-terminated */
        gboolean has_cccd;
    } chrc_meta[CHRC_COUNT] = {
        [CHRC_PROVIDER_NAME]   = { BEARER_PROVIDER_NAME_UUID,      {"read","notify",NULL},   TRUE  },
        [CHRC_UCI]             = { BEARER_UCI_UUID,                 {"read",NULL},            FALSE },
        [CHRC_TECHNOLOGY]      = { BEARER_TECHNOLOGY_UUID,          {"read","notify",NULL},   TRUE  },
        [CHRC_URI_SCHEMES]     = { BEARER_URI_SCHEMES_UUID,         {"read","notify",NULL},   TRUE  },
        [CHRC_SIGNAL_STRENGTH] = { BEARER_SIGNAL_STRENGTH_UUID,     {"read","notify",NULL},   TRUE  },
        [CHRC_CURRENT_CALLS]   = { BEARER_LIST_CURRENT_CALLS_UUID,  {"read","notify",NULL},   TRUE  },
        [CHRC_CCID]            = { CONTENT_CONTROL_ID_UUID,         {"read",NULL},            FALSE },
        [CHRC_STATUS_FLAGS]    = { STATUS_FLAGS_UUID,               {"read","notify",NULL},   TRUE  },
        [CHRC_CALL_STATE]      = { CALL_STATE_UUID,                 {"read","notify",NULL},   TRUE  },
        [CHRC_CCP]             = { CALL_CONTROL_POINT_UUID,         {"write","write-without-response","notify",NULL}, TRUE },
        [CHRC_CCP_OPC]         = { CALL_CONTROL_POINT_OPC_UUID,     {"read",NULL},            FALSE },
        [CHRC_TERM_REASON]     = { TERMINATION_REASON_UUID,         {"notify",NULL},          TRUE  },
        [CHRC_INCOMING_CALL]   = { INCOMING_CALL_UUID,              {"read","notify",NULL},   TRUE  },
        [CHRC_FRIENDLY_NAME]   = { CALL_FRIENDLY_NAME_UUID,         {"read","notify",NULL},   TRUE  },
    };

    GVariantBuilder root;
    g_variant_builder_init(&root, G_VARIANT_TYPE("a{oa{sa{sv}}}"));

    /* ── Service entry ── */
    {
        GVariantBuilder svc_iface, svc_prop;
        g_variant_builder_init(&svc_iface, G_VARIANT_TYPE("a{sa{sv}}"));
        g_variant_builder_init(&svc_prop,  G_VARIANT_TYPE("a{sv}"));

        g_variant_builder_add(&svc_prop, "{sv}", "UUID",
                              g_variant_new_string(GTBS_UUID));
        g_variant_builder_add(&svc_prop, "{sv}", "Primary",
                              g_variant_new_boolean(TRUE));

        /* Characteristics array */
        GVariantBuilder chrc_arr;
        g_variant_builder_init(&chrc_arr, G_VARIANT_TYPE("ao"));
        for (int i = 0; i < CHRC_COUNT; i++)
            g_variant_builder_add(&chrc_arr, "o", g_chrc_paths[i]);
        g_variant_builder_add(&svc_prop, "{sv}", "Characteristics",
                              g_variant_builder_end(&chrc_arr));

        g_variant_builder_add(&svc_iface, "{sa{sv}}", GATT_SERVICE_IFACE,
                              &svc_prop);
        g_variant_builder_add(&root, "{oa{sa{sv}}}", SVC_PATH, &svc_iface);
    }

    /* ── Characteristic entries ── */
    for (int i = 0; i < CHRC_COUNT; i++) {
        GVariantBuilder chrc_iface, chrc_prop;
        g_variant_builder_init(&chrc_iface, G_VARIANT_TYPE("a{sa{sv}}"));
        g_variant_builder_init(&chrc_prop,  G_VARIANT_TYPE("a{sv}"));

        g_variant_builder_add(&chrc_prop, "{sv}", "Service",
                              g_variant_new_object_path(SVC_PATH));
        g_variant_builder_add(&chrc_prop, "{sv}", "UUID",
                              g_variant_new_string(chrc_meta[i].uuid));

        GVariantBuilder flags;
        g_variant_builder_init(&flags, G_VARIANT_TYPE("as"));
        for (int f = 0; chrc_meta[i].flags[f]; f++)
            g_variant_builder_add(&flags, "s", chrc_meta[i].flags[f]);
        g_variant_builder_add(&chrc_prop, "{sv}", "Flags",
                              g_variant_builder_end(&flags));

        GVariantBuilder desc_arr;
        g_variant_builder_init(&desc_arr, G_VARIANT_TYPE("ao"));
        if (chrc_meta[i].has_cccd)
            g_variant_builder_add(&desc_arr, "o", g_cccd_paths[i]);
        g_variant_builder_add(&chrc_prop, "{sv}", "Descriptors",
                              g_variant_builder_end(&desc_arr));

        g_variant_builder_add(&chrc_iface, "{sa{sv}}", GATT_CHRC_IFACE,
                              &chrc_prop);
        g_variant_builder_add(&root, "{oa{sa{sv}}}", g_chrc_paths[i],
                              &chrc_iface);

        /* ── CCCD descriptor entry ── */
        if (chrc_meta[i].has_cccd) {
            GVariantBuilder desc_iface, desc_prop;
            g_variant_builder_init(&desc_iface, G_VARIANT_TYPE("a{sa{sv}}"));
            g_variant_builder_init(&desc_prop,  G_VARIANT_TYPE("a{sv}"));

            g_variant_builder_add(&desc_prop, "{sv}", "Characteristic",
                                  g_variant_new_object_path(g_chrc_paths[i]));
            g_variant_builder_add(&desc_prop, "{sv}", "UUID",
                                  g_variant_new_string(CCCD_UUID));

            GVariantBuilder dflags;
            g_variant_builder_init(&dflags, G_VARIANT_TYPE("as"));
            g_variant_builder_add(&dflags, "s", "read");
            g_variant_builder_add(&dflags, "s", "write");
            g_variant_builder_add(&desc_prop, "{sv}", "Flags",
                                  g_variant_builder_end(&dflags));

            g_variant_builder_add(&desc_iface, "{sa{sv}}", GATT_DESC_IFACE,
                                  &desc_prop);
            g_variant_builder_add(&root, "{oa{sa{sv}}}", g_cccd_paths[i],
                                  &desc_iface);
        }
    }

    g_dbus_method_invocation_return_value(inv,
        g_variant_new_tuple(
            (GVariant *[]){ g_variant_builder_end(&root) }, 1));
}

/* ── BlueZ registration callbacks ─────────────────────────────────────── */

static void on_registered(GObject *src, GAsyncResult *res, gpointer data)
{
    (void)src; (void)data;
    GError *err = NULL;
    GVariant *ret = g_dbus_connection_call_finish(G_DBUS_CONNECTION(src), res, &err);
    if (err) {
        g_printerr("[GTBS] RegisterApplication failed: %s\n", err->message);
        g_error_free(err);
        g_main_loop_quit(g_loop);
        return;
    }
    if (ret) g_variant_unref(ret);
    g_print("[GTBS] GATT application registered with BlueZ successfully\n");
    g_print("[GTBS] Waiting for nRF peripheral to connect and discover GTBS...\n");
}

/* ── Signal handler ─────────────────────────────────────────────────────── */
static void on_sigint(int sig)
{
    (void)sig;
    g_print("\n[GTBS] Shutting down\n");
    g_main_loop_quit(g_loop);
}

/* ── Main ────────────────────────────────────────────────────────────────── */
int main(void)
{
    GError *err = NULL;
    signal(SIGINT, on_sigint);

    /* ── Init characteristic values ── */
    g_chrc_values[CHRC_PROVIDER_NAME]   = bytes_from_utf8("LinuxCG");
    g_chrc_values[CHRC_UCI]             = bytes_from_utf8("un");
    g_chrc_values[CHRC_TECHNOLOGY]      = bytes_from_u8(BEARER_TECHNOLOGY_LTE);
    g_chrc_values[CHRC_URI_SCHEMES]     = bytes_from_utf8("tel");
    g_chrc_values[CHRC_SIGNAL_STRENGTH] = bytes_from_u8(80);
    g_chrc_values[CHRC_CURRENT_CALLS]   = g_byte_array_new();
    g_chrc_values[CHRC_CCID]            = bytes_from_u8(0x01);
    g_chrc_values[CHRC_STATUS_FLAGS]    = bytes_from_u16le(0x0000);
    g_chrc_values[CHRC_CALL_STATE]      = g_byte_array_new();
    g_chrc_values[CHRC_CCP]             = g_byte_array_new();
    g_chrc_values[CHRC_CCP_OPC]         = bytes_from_u16le(0x0003);
    g_chrc_values[CHRC_TERM_REASON]     = g_byte_array_new();
    g_chrc_values[CHRC_INCOMING_CALL]   = g_byte_array_new();
    g_chrc_values[CHRC_FRIENDLY_NAME]   = g_byte_array_new();

    /* ── Build object paths ── */
    for (int i = 0; i < CHRC_COUNT; i++) {
        snprintf(g_chrc_paths[i],  sizeof(g_chrc_paths[i]),
                 SVC_PATH "/char%04d", i);
        /* CCCD paths — only for notifiable chrcs (non-empty flag list with notify) */
        static const gboolean has_cccd[CHRC_COUNT] = {
            TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, TRUE,
            TRUE, TRUE, FALSE, TRUE, TRUE, TRUE
        };
        if (has_cccd[i])
            snprintf(g_cccd_paths[i], sizeof(g_cccd_paths[i]),
                     "%s/desc0000", g_chrc_paths[i]);
    }

    /* ── Connect to system D-Bus ── */
    g_bus = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, &err);
    if (!g_bus) {
        g_printerr("[GTBS] Cannot connect to system bus: %s\n", err->message);
        return 1;
    }

    /* ── Register vtables ── */
    static const GDBusInterfaceVTable chrc_vtable = {
        chrc_method_call, NULL, NULL, {0}
    };
    static const GDBusInterfaceVTable desc_vtable = {
        desc_method_call, NULL, NULL, {0}
    };
    static const GDBusInterfaceVTable app_vtable = {
        app_method_call, NULL, NULL, {0}
    };

    /* Build minimal introspection XML for each interface */
    static const char *chrc_xml =
        "<node>"
        "  <interface name='" GATT_CHRC_IFACE "'>"
        "    <method name='ReadValue'>"
        "      <arg type='a{sv}' direction='in'/>"
        "      <arg type='ay' direction='out'/>"
        "    </method>"
        "    <method name='WriteValue'>"
        "      <arg type='ay' direction='in'/>"
        "      <arg type='a{sv}' direction='in'/>"
        "    </method>"
        "    <method name='StartNotify'/>"
        "    <method name='StopNotify'/>"
        "    <signal name='PropertiesChanged'>"
        "      <arg type='s'/><arg type='a{sv}'/><arg type='as'/>"
        "    </signal>"
        "  </interface>"
        "</node>";

    static const char *desc_xml =
        "<node>"
        "  <interface name='" GATT_DESC_IFACE "'>"
        "    <method name='ReadValue'>"
        "      <arg type='a{sv}' direction='in'/>"
        "      <arg type='ay' direction='out'/>"
        "    </method>"
        "    <method name='WriteValue'>"
        "      <arg type='ay' direction='in'/>"
        "      <arg type='a{sv}' direction='in'/>"
        "    </method>"
        "  </interface>"
        "</node>";

    static const char *app_xml =
        "<node>"
        "  <interface name='" DBUS_OM_IFACE "'>"
        "    <method name='GetManagedObjects'>"
        "      <arg type='a{oa{sa{sv}}}' direction='out'/>"
        "    </method>"
        "  </interface>"
        "</node>";

    GDBusNodeInfo *chrc_info = g_dbus_node_info_new_for_xml(chrc_xml, NULL);
    GDBusNodeInfo *desc_info = g_dbus_node_info_new_for_xml(desc_xml, NULL);
    GDBusNodeInfo *app_info  = g_dbus_node_info_new_for_xml(app_xml, NULL);

    /* Register app root */
    g_reg_ids[g_reg_count++] = g_dbus_connection_register_object(
        g_bus, APP_PATH,
        app_info->interfaces[0],
        &app_vtable, NULL, NULL, &err);

    /* Register service object (no methods, just for path existence) */
    g_reg_ids[g_reg_count++] = g_dbus_connection_register_object(
        g_bus, SVC_PATH,
        app_info->interfaces[0],  /* reuse OM iface as placeholder */
        &app_vtable, NULL, NULL, NULL);

    /* Register each characteristic and CCCD */
    static const gboolean has_cccd_tbl[CHRC_COUNT] = {
        TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, TRUE,
        TRUE, TRUE, FALSE, TRUE, TRUE, TRUE
    };
    for (int i = 0; i < CHRC_COUNT; i++) {
        g_reg_ids[g_reg_count++] = g_dbus_connection_register_object(
            g_bus, g_chrc_paths[i],
            chrc_info->interfaces[0],
            &chrc_vtable, NULL, NULL, &err);
        if (err) {
            g_printerr("[GTBS] register chrc %d: %s\n", i, err->message);
            g_error_free(err); err = NULL;
        }

        if (has_cccd_tbl[i]) {
            g_reg_ids[g_reg_count++] = g_dbus_connection_register_object(
                g_bus, g_cccd_paths[i],
                desc_info->interfaces[0],
                &desc_vtable, NULL, NULL, &err);
            if (err) {
                g_printerr("[GTBS] register cccd %d: %s\n", i, err->message);
                g_error_free(err); err = NULL;
            }
        }
    }

    g_dbus_node_info_unref(chrc_info);
    g_dbus_node_info_unref(desc_info);
    g_dbus_node_info_unref(app_info);

    /* ── Print info ── */
    g_print("[GTBS] Registering GATT application at " APP_PATH "\n");
    g_print("[GTBS] GTBS service UUID: " GTBS_UUID "\n");

    /* ── Call RegisterApplication on BlueZ ── */
    g_dbus_connection_call(
        g_bus,
        BLUEZ_SERVICE,
        "/org/bluez/hci0",
        GATT_MANAGER_IFACE,
        "RegisterApplication",
        g_variant_new("(oa{sv})", APP_PATH, NULL),
        NULL,
        G_DBUS_CALL_FLAGS_NONE,
        -1,
        NULL,
        on_registered,
        NULL);

    g_loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(g_loop);

    /* ── Cleanup ── */
    g_dbus_connection_call_sync(
        g_bus, BLUEZ_SERVICE, "/org/bluez/hci0",
        GATT_MANAGER_IFACE, "UnregisterApplication",
        g_variant_new("(o)", APP_PATH),
        NULL, G_DBUS_CALL_FLAGS_NONE, -1, NULL, NULL);

    for (guint i = 0; i < g_reg_count; i++)
        g_dbus_connection_unregister_object(g_bus, g_reg_ids[i]);

    for (int i = 0; i < CHRC_COUNT; i++)
        g_byte_array_free(g_chrc_values[i], TRUE);

    g_object_unref(g_bus);
    g_main_loop_unref(g_loop);
    return 0;
}
