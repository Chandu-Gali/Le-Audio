/*
 * tmas_server.c — Telephony and Media Audio Service (TMAS) GATT Server
 *
 * Registers with BlueZ so the nRF's bt_tmap_discover() succeeds.
 * Exposes BT_TMAP_ROLE_CG | BT_TMAP_ROLE_UMS (0x0005) as the TMAP Role
 * characteristic, matching what the nRF expects from a CG peer.
 *
 * Run alongside gtbs_server:
 *   ./tmas_server &
 *   ./gtbs_server
 *
 * Build:
 *   gcc $(pkg-config --cflags --libs gio-2.0 glib-2.0) -o tmas_server tmas_server.c
 */

#include <gio/gio.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* ── UUIDs ──────────────────────────────────────────────────────────────── */
#define TMAS_UUID           "00001855-0000-1000-8000-00805f9b34fb"
#define TMAP_ROLE_CHRC_UUID "00002b51-0000-1000-8000-00805f9b34fb"

/* ── D-Bus constants ────────────────────────────────────────────────────── */
#define BLUEZ_SERVICE      "org.bluez"
#define DBUS_OM_IFACE      "org.freedesktop.DBus.ObjectManager"
#define GATT_MANAGER_IFACE "org.bluez.GattManager1"
#define GATT_SERVICE_IFACE "org.bluez.GattService1"
#define GATT_CHRC_IFACE    "org.bluez.GattCharacteristic1"

#define APP_PATH           "/tmas/app"
#define SVC_PATH           APP_PATH "/service0"
#define CHRC_PATH          SVC_PATH "/char0000"

/* ── TMAP Role bitmask ──────────────────────────────────────────────────── */
#define BT_TMAP_ROLE_CG   0x0001  /* Call Gateway         */
#define BT_TMAP_ROLE_CT   0x0002  /* Call Terminal        */
#define BT_TMAP_ROLE_UMS  0x0004  /* Unicast Media Sender */
#define BT_TMAP_ROLE_UMR  0x0008  /* Unicast Media Receiver */
#define BT_TMAP_ROLE_BMS  0x0010  /* Broadcast Media Sender */
#define BT_TMAP_ROLE_BMR  0x0020  /* Broadcast Media Receiver */

/* This Linux host acts as CG + UMS */
#define LOCAL_TMAP_ROLE   (BT_TMAP_ROLE_CG | BT_TMAP_ROLE_UMS)  /* 0x0005 */

/* ── Global state ───────────────────────────────────────────────────────── */
static GDBusConnection *g_bus  = NULL;
static GMainLoop       *g_loop = NULL;

/* TMAP Role value: 2-byte little-endian */
static const guint8 g_role_value[2] = {
    (guint8)(LOCAL_TMAP_ROLE & 0xFF),
    (guint8)((LOCAL_TMAP_ROLE >> 8) & 0xFF)
};

/* ── ObjectManager.GetManagedObjects ────────────────────────────────────── */
static void app_method_call(GDBusConnection *conn,
                             const gchar *sender,
                             const gchar *obj_path,
                             const gchar *iface,
                             const gchar *method,
                             GVariant *params,
                             GDBusMethodInvocation *inv,
                             gpointer user_data)
{
    (void)conn; (void)sender; (void)obj_path; (void)iface;
    (void)params; (void)user_data;

    if (strcmp(method, "GetManagedObjects") != 0) {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method %s", method);
        return;
    }

    GVariantBuilder root;
    g_variant_builder_init(&root, G_VARIANT_TYPE("a{oa{sa{sv}}}"));

    /* ── Service entry ── */
    {
        GVariantBuilder svc_iface, svc_prop;
        g_variant_builder_init(&svc_iface, G_VARIANT_TYPE("a{sa{sv}}"));
        g_variant_builder_init(&svc_prop,  G_VARIANT_TYPE("a{sv}"));

        g_variant_builder_add(&svc_prop, "{sv}", "UUID",
                              g_variant_new_string(TMAS_UUID));
        g_variant_builder_add(&svc_prop, "{sv}", "Primary",
                              g_variant_new_boolean(TRUE));

        GVariantBuilder chrc_arr;
        g_variant_builder_init(&chrc_arr, G_VARIANT_TYPE("ao"));
        g_variant_builder_add(&chrc_arr, "o", CHRC_PATH);
        g_variant_builder_add(&svc_prop, "{sv}", "Characteristics",
                              g_variant_builder_end(&chrc_arr));

        g_variant_builder_add(&svc_iface, "{sa{sv}}",
                              GATT_SERVICE_IFACE, &svc_prop);
        g_variant_builder_add(&root, "{oa{sa{sv}}}", SVC_PATH, &svc_iface);
    }

    /* ── TMAP Role characteristic entry ── */
    {
        GVariantBuilder chrc_iface, chrc_prop;
        g_variant_builder_init(&chrc_iface, G_VARIANT_TYPE("a{sa{sv}}"));
        g_variant_builder_init(&chrc_prop,  G_VARIANT_TYPE("a{sv}"));

        g_variant_builder_add(&chrc_prop, "{sv}", "Service",
                              g_variant_new_object_path(SVC_PATH));
        g_variant_builder_add(&chrc_prop, "{sv}", "UUID",
                              g_variant_new_string(TMAP_ROLE_CHRC_UUID));

        GVariantBuilder flags;
        g_variant_builder_init(&flags, G_VARIANT_TYPE("as"));
        g_variant_builder_add(&flags, "s", "read");
        g_variant_builder_add(&chrc_prop, "{sv}", "Flags",
                              g_variant_builder_end(&flags));

        g_variant_builder_add(&chrc_prop, "{sv}", "Descriptors",
                              g_variant_new_array(G_VARIANT_TYPE_OBJECT_PATH,
                                                  NULL, 0));

        g_variant_builder_add(&chrc_iface, "{sa{sv}}",
                              GATT_CHRC_IFACE, &chrc_prop);
        g_variant_builder_add(&root, "{oa{sa{sv}}}", CHRC_PATH, &chrc_iface);
    }

    g_dbus_method_invocation_return_value(inv,
        g_variant_new_tuple(
            (GVariant *[]){ g_variant_builder_end(&root) }, 1));
}

/* ── GattCharacteristic1 method handler ─────────────────────────────────── */
static void chrc_method_call(GDBusConnection *conn,
                              const gchar *sender,
                              const gchar *obj_path,
                              const gchar *iface,
                              const gchar *method,
                              GVariant *params,
                              GDBusMethodInvocation *inv,
                              gpointer user_data)
{
    (void)conn; (void)sender; (void)obj_path; (void)iface;
    (void)params; (void)user_data;

    if (strcmp(method, "ReadValue") == 0) {
        guint16 role_val = LOCAL_TMAP_ROLE;
        GString *roles = g_string_new(NULL);
        if (role_val & BT_TMAP_ROLE_CG)  g_string_append(roles, "CG+");
        if (role_val & BT_TMAP_ROLE_CT)  g_string_append(roles, "CT+");
        if (role_val & BT_TMAP_ROLE_UMS) g_string_append(roles, "UMS+");
        if (role_val & BT_TMAP_ROLE_UMR) g_string_append(roles, "UMR+");
        if (roles->len > 0 && roles->str[roles->len - 1] == '+')
            g_string_truncate(roles, roles->len - 1);

        g_print("[TMAS] TMAPRole read → 0x%04x (%s)\n", role_val, roles->str);
        g_string_free(roles, TRUE);

        GVariantBuilder b;
        g_variant_builder_init(&b, G_VARIANT_TYPE("ay"));
        g_variant_builder_add(&b, "y", g_role_value[0]);
        g_variant_builder_add(&b, "y", g_role_value[1]);
        GVariant *ret = g_variant_builder_end(&b);
        g_dbus_method_invocation_return_value(inv,
            g_variant_new_tuple(&ret, 1));
    } else {
        g_dbus_method_invocation_return_error(inv, G_DBUS_ERROR,
            G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method %s", method);
    }
}

/* ── BlueZ registration callback ────────────────────────────────────────── */
static void on_registered(GObject *src, GAsyncResult *res, gpointer data)
{
    (void)src; (void)data;
    GError *err = NULL;
    GVariant *ret = g_dbus_connection_call_finish(G_DBUS_CONNECTION(src),
                                                   res, &err);
    if (err) {
        g_printerr("[TMAS] RegisterApplication failed: %s\n", err->message);
        g_error_free(err);
        g_main_loop_quit(g_loop);
        return;
    }
    if (ret) g_variant_unref(ret);
    g_print("[TMAS] GATT application registered with BlueZ successfully\n");
    g_print("[TMAS] Serving TMAP Role = CG+UMS (0x%04x)\n", LOCAL_TMAP_ROLE);
    g_print("[TMAS] nRF bt_tmap_discover() will now succeed\n");
}

/* ── Signal handler ─────────────────────────────────────────────────────── */
static void on_sigint(int sig)
{
    (void)sig;
    g_print("\n[TMAS] Shutting down\n");
    g_main_loop_quit(g_loop);
}

/* ── Main ────────────────────────────────────────────────────────────────── */
int main(void)
{
    GError *err = NULL;
    signal(SIGINT, on_sigint);

    g_print("[TMAS] Registering TMAS GATT application at " APP_PATH "\n");
    g_print("[TMAS] TMAS UUID:      " TMAS_UUID "\n");
    g_print("[TMAS] Role char UUID: " TMAP_ROLE_CHRC_UUID "\n");

    /* ── Connect to system D-Bus ── */
    g_bus = g_bus_get_sync(G_BUS_TYPE_SYSTEM, NULL, &err);
    if (!g_bus) {
        g_printerr("[TMAS] Cannot connect to system bus: %s\n", err->message);
        return 1;
    }

    /* ── Introspection XML ── */
    static const char *app_xml =
        "<node>"
        "  <interface name='" DBUS_OM_IFACE "'>"
        "    <method name='GetManagedObjects'>"
        "      <arg type='a{oa{sa{sv}}}' direction='out'/>"
        "    </method>"
        "  </interface>"
        "</node>";

    static const char *chrc_xml =
        "<node>"
        "  <interface name='" GATT_CHRC_IFACE "'>"
        "    <method name='ReadValue'>"
        "      <arg type='a{sv}' direction='in'/>"
        "      <arg type='ay' direction='out'/>"
        "    </method>"
        "  </interface>"
        "</node>";

    GDBusNodeInfo *app_info  = g_dbus_node_info_new_for_xml(app_xml, NULL);
    GDBusNodeInfo *chrc_info = g_dbus_node_info_new_for_xml(chrc_xml, NULL);

    static const GDBusInterfaceVTable app_vtable  = { app_method_call,  NULL, NULL, {0} };
    static const GDBusInterfaceVTable chrc_vtable = { chrc_method_call, NULL, NULL, {0} };

    guint reg_app  = g_dbus_connection_register_object(
        g_bus, APP_PATH,  app_info->interfaces[0],  &app_vtable,  NULL, NULL, &err);
    if (err) { g_printerr("[TMAS] register app: %s\n",  err->message); g_error_free(err); err = NULL; }

    guint reg_svc  = g_dbus_connection_register_object(
        g_bus, SVC_PATH,  app_info->interfaces[0],  &app_vtable,  NULL, NULL, &err);
    if (err) { g_printerr("[TMAS] register svc: %s\n",  err->message); g_error_free(err); err = NULL; }

    guint reg_chrc = g_dbus_connection_register_object(
        g_bus, CHRC_PATH, chrc_info->interfaces[0], &chrc_vtable, NULL, NULL, &err);
    if (err) { g_printerr("[TMAS] register chrc: %s\n", err->message); g_error_free(err); err = NULL; }

    g_dbus_node_info_unref(app_info);
    g_dbus_node_info_unref(chrc_info);

    /* ── Call RegisterApplication on BlueZ ── */
    g_dbus_connection_call(
        g_bus,
        BLUEZ_SERVICE,
        "/org/bluez/hci0",
        GATT_MANAGER_IFACE,
        "RegisterApplication",
        g_variant_new("(oa{sv})", APP_PATH, NULL),
        NULL,
        G_DBUS_CALL_FLAGS_NONE,
        -1, NULL,
        on_registered, NULL);

    g_loop = g_main_loop_new(NULL, FALSE);
    g_main_loop_run(g_loop);

    /* ── Cleanup ── */
    g_dbus_connection_call_sync(
        g_bus, BLUEZ_SERVICE, "/org/bluez/hci0",
        GATT_MANAGER_IFACE, "UnregisterApplication",
        g_variant_new("(o)", APP_PATH),
        NULL, G_DBUS_CALL_FLAGS_NONE, -1, NULL, NULL);

    g_dbus_connection_unregister_object(g_bus, reg_app);
    g_dbus_connection_unregister_object(g_bus, reg_svc);
    g_dbus_connection_unregister_object(g_bus, reg_chrc);

    g_object_unref(g_bus);
    g_main_loop_unref(g_loop);
    return 0;
}
